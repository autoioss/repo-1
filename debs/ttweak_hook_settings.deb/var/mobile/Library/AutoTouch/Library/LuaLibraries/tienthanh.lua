local TienThanh = {}

local function request(url)
    local baseUrl = "http://localhost:3004/";
    local http = require("socket.http")
    local body, code, headers, status = http.request(baseUrl .. url);
end

function TienThanh.kill()
    local url = "service/kill";
    request(url);

end

function TienThanh.logContent()
    print("etst")
end
return TienThanh
